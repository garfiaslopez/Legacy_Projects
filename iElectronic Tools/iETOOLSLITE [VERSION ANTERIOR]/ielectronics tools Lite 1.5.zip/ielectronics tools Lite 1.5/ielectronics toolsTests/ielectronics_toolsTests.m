//
//  ielectronics_toolsTests.m
//  ielectronics toolsTests
//
//  Created by Jose Garfias Lopez on 17/12/12.
//  Copyright (c) 2012 Jose Garfias Lopez. All rights reserved.
//

#import "ielectronics_toolsTests.h"

@implementation ielectronics_toolsTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in ielectronics toolsTests");
}

@end
