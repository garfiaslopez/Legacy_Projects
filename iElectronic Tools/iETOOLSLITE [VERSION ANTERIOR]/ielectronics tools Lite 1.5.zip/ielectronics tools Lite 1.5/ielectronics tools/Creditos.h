//
//  Creditos.h
//  ielectronics tools
//
//  Created by Jose Garfias Lopez on 04/03/13.
//  Copyright (c) 2013 Jose Garfias Lopez. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Creditos : UIViewController

@property (weak, nonatomic) IBOutlet UINavigationBar *Tittle;

-(IBAction)inicio:(id)sender;

-(IBAction)Cargafacebook:(id)sender;
-(IBAction)Cargatwitter:(id)sender;
@end
