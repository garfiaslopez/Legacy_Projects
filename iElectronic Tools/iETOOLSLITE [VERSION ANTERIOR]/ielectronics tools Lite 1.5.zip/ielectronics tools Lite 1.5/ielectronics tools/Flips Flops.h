//
//  Flips Flops.h
//  iElectronic Tools PRO
//
//  Created by Jose Garfias Lopez on 25/06/13.
//  Copyright (c) 2013 Jose Garfias Lopez. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Flips_Flops : UIViewController


@property (strong, nonatomic) IBOutlet UINavigationBar *TituloNav;
@property (strong, nonatomic) IBOutlet UIScrollView *Scroller;












- (IBAction)Inicio:(id)sender;
- (IBAction)Ayuda:(id)sender;



@end
