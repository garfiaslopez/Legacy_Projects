//
//  ConversorUnitOhms.h
//  ielectronics tools
//
//  Created by Jose Garfias Lopez on 30/12/12.
//  Copyright (c) 2012 Jose Garfias Lopez. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ConversorUnitOhms : UIViewController

@end
