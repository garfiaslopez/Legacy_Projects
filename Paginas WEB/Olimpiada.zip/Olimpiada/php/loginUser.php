<?php

	$db_host = "localhost";
	$db_username = "garfiaslopez";
	$db_pass = "jose12JESUS";
	$db_name = "Olimpiada";
	$db_table= "Usuarios";

?>